import psycopg2
def table():
   
    conn = psycopg2.connect(dbname="postgres", user="postgres", password="Negi@2008", host="localhost", port="5432")

    cursor = conn.cursor()
    cursor.execute('''create table employees(Name Text, ID int, age int);''')
    print("Table created successfully")

    conn.commit()
    conn.close()

def data():
   
    conn = psycopg2.connect(dbname="postgres", user="postgres", password="Negi@2008", host="localhost", port="5432")

    cursor = conn.cursor()
    cursor.execute('''insert into employees(Name,ID,age) values('Sach',01,14);''')
    print("Data inserted successfully")

    conn.commit()
    conn.close()

def extract():
   
    conn = psycopg2.connect(dbname="postgres", user="postgres", password="Negi@2008", host="localhost", port="5432")

    cursor = conn.cursor()
    cursor.execute('''select  * from employees;''')
    show = cursor.fetchone()
    print(show[1])
    print(show[2])

    conn.commit()
    conn.close()

extract()

